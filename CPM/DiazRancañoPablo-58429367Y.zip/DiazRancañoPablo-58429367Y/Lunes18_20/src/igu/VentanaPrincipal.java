package igu;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;
import java.awt.FlowLayout;

import logica.Casilla;
import logica.Juego;
import logica.Tablero;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import java.awt.Font;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panel;
	private JButton btAvance;
	private Tablero tablero;
	private int numCasillas;
	private JButton btRetroceso;
	private Juego juego;
	private JMenuBar menuBar;
	private JMenu mnJuego;
	private JMenuItem mntmNuevo;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JLabel lblPuntuacion;
	private JLabel lbPuntos;
	private JMenu mnAyuda;
	private JMenuItem mntmAcercaDe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tablero= new Tablero();
		juego= new Juego();
		numCasillas= tablero.getNumCasillas();
		setBounds(100, 100, 1001, 489);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getPanelTablero());
		contentPane.add(getBtAvance());
		crearBotonesPanel(getPanelTablero());
		contentPane.add(getBtRetroceso());
		contentPane.add(getLblPuntuacion());
		contentPane.add(getLbPuntos());
		jugar();
	}

	private JPanel getPanelTablero() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBounds(40, 67, 908, 103);
			panel.setLayout(new GridLayout(1, numCasillas, 0, 0));
		}
		return panel;
	}
	
	private JButton getBtAvance() {
		if (btAvance == null) {
			btAvance = new JButton("ADELANTE");
			btAvance.setMnemonic('D');
			btAvance.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) 
				{
					avanzar();
				}
			});
			btAvance.setBounds(551, 204, 135, 25);
		}
		return btAvance;
	}
	
	private void avanzar()
	{
		tablero.avanzarCiclista();
		jugar();
	}
	
	private void setImagenAdaptada(JButton boton, String rutaImagen){
		 this.setVisible(true);
		 Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage(); 
		 Image imgEscalada = imgOriginal.getScaledInstance(boton.getWidth(),
				 boton.getHeight(), Image.SCALE_FAST);
		 ImageIcon icon = new ImageIcon(imgEscalada);
		 boton.setIcon(icon);
		 boton.setDisabledIcon(icon);
	}
	
	private void crearBotonesPanel(JPanel panel)
	{
		for (int i=0; i< numCasillas; i++)
		{	
			panel.add(crearBoton(i));
		}
	}
	
	private JButton crearBoton(int posicion)
	{
		JButton boton= new JButton();
		boton.setActionCommand(String.valueOf(posicion));
		boton.setBackground(Color.WHITE);
		boton.setEnabled(false);
		
		if (posicion == numCasillas - 1)
		{
			boton.setText("META");
		}
		
		return boton;
	}
	
	private JButton getBtRetroceso() {
		if (btRetroceso == null) {
			btRetroceso = new JButton("ATR\u00C1S");
			btRetroceso.setMnemonic('A');
			btRetroceso.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) 
				{
					retroceder();
				}
			});
			btRetroceso.setBounds(359, 205, 89, 23);
		}
		return btRetroceso;
	}
	
	private void retroceder()
	{
		tablero.retrocederCiclista();
		jugar();
	}
	
	private void pintarTablero()
	{
		Component[] botones= getPanelTablero().getComponents();
		String imagen = "/img/ciclista.png";
		
		for (int i=0; i< botones.length; i++)
		{
			if (i== tablero.getPosCiclista())
			{
				tablero.incrementarPuntuacion(tablero.getCasilla(i).getValor());
				JButton boton= (JButton) botones[i];
				setImagenAdaptada(boton, imagen);
				
				if (tablero.getPosCiclista() == tablero.getPosMeta())
				{
					reiniciarJuego();
				}
			}
			
			else
			{
				JButton boton= (JButton) botones[i];
				boton.setIcon(null);
			}
		}
	}
	
	private void jugar()
	{
		pintarPuntuacion();
		pintarTablero();
	}
	
	private void reiniciarJuego()
	{
		JOptionPane.showMessageDialog(getPanelTablero(), "Final de la partida.");
		modificarBotones(false);
	}
	
	private void modificarBotones(boolean estado)
	{
		getBtRetroceso().setEnabled(estado);
		getBtAvance().setEnabled(estado);
	}
	
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnJuego());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	
	private JMenu getMnJuego() {
		if (mnJuego == null) {
			mnJuego = new JMenu("Juego");
			mnJuego.setMnemonic('J');
			mnJuego.add(getMntmNuevo());
			mnJuego.add(getSeparator());
			mnJuego.add(getMntmSalir());
		}
		return mnJuego;
	}
	
	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) 
				{
					inicializar();
				}
			});
			mntmNuevo.setMnemonic('N');
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
		}
		return mntmNuevo;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) 
				{
					System.exit(0);
				}
			});
			mntmSalir.setMnemonic('S');
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		}
		return mntmSalir;
	}
	
	private JLabel getLblPuntuacion() {
		if (lblPuntuacion == null) {
			lblPuntuacion = new JLabel("PUNTUACI\u00D3N");
			lblPuntuacion.setFont(new Font("Tahoma", Font.BOLD, 26));
			lblPuntuacion.setBounds(436, 0, 189, 66);
		}
		return lblPuntuacion;
	}
	
	private JLabel getLbPuntos() 
	{
		if (lbPuntos == null)
		{
			lbPuntos = new JLabel("0");
			lbPuntos.setForeground(Color.BLACK);
			lbPuntos.setFont(new Font("Tahoma", Font.BOLD, 28));
			lbPuntos.setBounds(631, 11, 102, 45);
		}
		return lbPuntos;
	}
	
	private void pintarPuntuacion()
	{
		int puntos= tablero.getPuntuacion();
		getLbPuntos().setText(String.valueOf(puntos));
	}
	
	private void inicializar()
	{
		tablero= new Tablero();
		modificarBotones(true);
		jugar();
	}
	
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('Y');
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca de");
			mntmAcercaDe.setMnemonic('D');
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) 
				{
					JOptionPane.showMessageDialog(contentPane, mostrarInformacion());
				}
			});
			mntmAcercaDe.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_MASK));
		}
		return mntmAcercaDe;
	}
	
	private String mostrarInformacion()
	{
		return "Pablo D�az Ranca�o\nDNI: 58429367Y";
	}
	
	class ProcesaBoton implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
		
	}
}
