package logica;

public class Casilla {
	
	private boolean tieneCiclista;
	private int valor;
	private int piedra;
	
	public Casilla()
	{
		tieneCiclista= false;
		setValor(50);
		piedra= 0;
	}

	public boolean getTieneCiclista()
	{
		return tieneCiclista;
	}
	
	public void setTieneCiclista(boolean newValue)
	{
		tieneCiclista= newValue;
	}
	
	public void setValor(int newValor)
	{
		valor= newValor;
	}
	
	public int getValor()
	{
		return valor;
	}
	
	public int getPiedra()
	{
		return piedra;
	}
}
