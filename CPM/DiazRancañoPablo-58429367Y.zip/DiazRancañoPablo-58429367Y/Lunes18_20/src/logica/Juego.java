package logica;

import java.util.Random;

public class Juego {
	
	public Juego(){
		inicializarJuego();
	}
	
	public void inicializarJuego()
	{
		
	}
	
}
