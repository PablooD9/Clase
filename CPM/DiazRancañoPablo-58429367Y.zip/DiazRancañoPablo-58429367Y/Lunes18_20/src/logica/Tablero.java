package logica;

import java.util.Random;

public class Tablero {
	
	public static int DIM = 10;
	
	private Casilla[] casillas= new Casilla[DIM];
	private int posCiclista;
	private int puntuacion;
	private int piedra;
	
	public Tablero()
	{
		for (int i=0; i< DIM; i++)
		{
			casillas[i]= new Casilla();
		}
		
		posCiclista= 0;
		puntuacion= 0;
		
		generarPosCiclista();
		
		colocarPiedra();
    }
	
	public int getNumCasillas()
	{
		return casillas.length;
	}
	
	private void generarPosCiclista()
	{
		Random random= new Random();
		int pos= random.nextInt(DIM - 1); //no coincide con la meta
		
		casillas[pos].setTieneCiclista(true);
		posCiclista= pos;
	}
	
	public int getPosCiclista()
	{
		return posCiclista;
	}
	
	public void avanzarCiclista()
	{
		if ((posCiclista + 1) <= DIM - 1)
		{
			posCiclista++;
		}
	}
	
	public void retrocederCiclista()
	{
		if ((posCiclista - 1) >= 0)
		{
			posCiclista--;
		}
	}
	
	public int getPosMeta()
	{
		return casillas.length - 1;
	}
	
	public void incrementarPuntuacion(int puntos)
	{
		if ((posCiclista - 1) >= 0 && (posCiclista + 1) <= DIM)
		{
			puntuacion += puntos;
		}
	}
	
	public Casilla getCasilla(int pos)
	{
		return casillas[pos];
	}
	
	public int getPuntuacion()
	{
		return puntuacion;
	}
	
	public void setPuntuacion(int newValor)
	{
		puntuacion += newValor;
	}
	
	private void colocarPiedra()
	{
		Random random= new Random();
		int pos= random.nextInt(DIM - 1);
		
		if (pos == 0)
		{
			pos++;
		}
	}

}
